import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'imageconf';
  AreaSelected:string="image";
  addClass:string="image";
  ngOnInit(): void {
    this.AreaSelected=sessionStorage.getItem('areaselected') || 'image';
    this.addClass=sessionStorage.getItem('addclass') || 'image';
    console.log("ngoninit :", this.AreaSelected);
  }
  SelectedArea(area:string): void {
    // Access properties of the clicked link
    // const targetLink = event.target as HTMLAnchorElement;
    if(area=="image"){
      this.AreaSelected=area;
      this.addClass=area;
    }
    else{
      this.AreaSelected=area;
      this.addClass=area;
    }
    sessionStorage.setItem('areaselected',this.AreaSelected as string);
    sessionStorage.setItem('addclass',this.addClass as string);
    console.log("fun :", this.AreaSelected);
    // Your custom logic here

    // Add a class to the clicked link
    // this.linkClicked = true;
  }
}
