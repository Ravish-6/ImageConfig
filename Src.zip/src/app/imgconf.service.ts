import { Injectable } from '@angular/core';
import * as pdfImage from 'pdf-image';
// import * as Caman from 'caman';
// import { PDFDocument } from 'pdf-lib';

@Injectable({
  providedIn: 'root'
})
export class ImgconfService {

  constructor() { }
  async convertToImages(pdfDataUrl: string): Promise<string[]> {
    const converter = pdfImage(pdfDataUrl); // Use the Data URL directly

    // Convert each page to an image
    const images = await Promise.all(
      Array.from({ length: converter.numberOfPages }, (_, i) => {
        return converter.convertPage(i + 1);
      })
    );

    return images;
  }
  async adjustImageProperties(imageDataUrl: string,contrast: number,brightness: number, saturation: number): Promise<string> {
    return new Promise((resolve) => {
      const image = new Image();
      image.src = imageDataUrl;

      image.onload = () => {
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');

        canvas.width = image.width;
        canvas.height = image.height;

        context.drawImage(image, 0, 0, image.width, image.height);

        // Adjust contrast, brightness, saturation using CamanJS
        Caman(canvas, function () {
          this.contrast(contrast); // Adjust the contrast value
          this.brightness(brightness); // Adjust the brightness value
          this.saturation(saturation); // Adjust the saturation value
          this.render(() => {
            // Get the adjusted image as a Data URL
            const adjustedDataUrl = canvas.toDataURL('image/png');
            resolve(adjustedDataUrl);
          });
        });
      };
    });
  }
}
