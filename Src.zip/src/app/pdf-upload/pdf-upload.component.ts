import { Component, OnInit, ElementRef, ViewChild  } from '@angular/core';
import { PDFDocument, rgb } from 'pdf-lib';
import { ImgconfService } from '../imgconf.service';
// import { read } from 'jimp';
// import { dataUriToBuffer } from 'data-uri-to-buffer';
// import { promises as fs } from 'fs';
// data-uri-to-buffer , jimp, fs
@Component({
  selector: 'app-pdf-upload',
  templateUrl: './pdf-upload.component.html',
  styleUrls: ['./pdf-upload.component.css']
})
export class PdfUploadComponent implements OnInit {
  @ViewChild('pdfCanvas', { static: true }) pdfCanvas: ElementRef<HTMLCanvasElement>;
  constructor( private MyService: ImgconfService) { }

  ngOnInit(): void {
  }
  // pdfSrc: string | ArrayBuffer;
  pdfSrc: string = "https://vadimdez.github.io/ng2-pdf-viewer/assets/pdf-test.pdf";

  // pdfSrc: string | ArrayBuffer;
  brightness = 100;
  contrast = 100;
  saturation = 100;
  imageFilter: string;

  

  onFileSelected(event: any): void {
    const fileInput = event.target;
    const file = fileInput.files[0];

    if (file) {
      const fileReader = new FileReader();

      fileReader.onload = () => {
        // Assigning the result as a data URL
        this.pdfSrc = fileReader.result as string;
      };

      fileReader.readAsDataURL(file);
    }
  }

  updateImageFilter(): void {
    this.imageFilter = `brightness(${this.brightness }%) contrast(${this.contrast }%) saturate(${this.saturation }%)`;
  }
  
  async downloadPdf():Promise<void>  {
    // Logic to download the PDF with applied filters
    
  
    const a = document.createElement('a');
    if (typeof this.pdfSrc === 'string') {
      // If dataUrl is a string, set the href attribute directly
      a.href = this.pdfSrc;
    }
    // else if (this.pdfSrc instanceof ArrayBuffer) {
    //   // If dataUrl is an ArrayBuffer, create a Blob and set the href attribute
    //   const blob = new Blob([this.pdfSrc], { type: 'application/pdf' });
    //   a.href = URL.createObjectURL(blob);
    // }
    else {
      // Handle other types if needed
      console.error('Unsupported dataUrl type');
      return;
    }

    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

}
