import { TestBed } from '@angular/core/testing';

import { ImgconfService } from './imgconf.service';

describe('ImgconfService', () => {
  let service: ImgconfService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ImgconfService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
