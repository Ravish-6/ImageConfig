import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeStyle } from '@angular/platform-browser';

@Component({
  selector: 'app-image-upload',
  templateUrl: './image-upload.component.html',
  styleUrls: ['./image-upload.component.css']
})
export class ImageUploadComponent implements OnInit {
  // constructor() { }
  imageUrl: Array<string | ArrayBuffer> = [];
  brightness = 50;
  contrast = 50;
  saturation = 50;
  imageFilter: SafeStyle; // Declare imageFilter here
  a:Array<number> =[];

  constructor(private sanitizer: DomSanitizer) {}
  ngOnInit(): void {
    const imgarr = JSON.parse(sessionStorage.getItem('ImgArr') || '[]');
    console.log(imgarr.length);
    if(imgarr.length>0){
      this.imageUrl=imgarr;
    }
    // const savedImage = sessionStorage.getItem('uploadedImage');
    // if (savedImage) {
    //   this.imageUrl = savedImage;
    // }
  }
  


  onFileSelected(event: any): void {
    const files = event.target.files;
    if (files && files.length>0) {
      this.imageUrl=[];
      for(let i=0;i<files.length;i++){
        const file=files[i];
        const reader=new FileReader();
        reader.onload = () =>{
          this.imageUrl.push(reader.result as string);
          console.log(this.imageUrl);
          sessionStorage.setItem('ImgArr', JSON.stringify(this.imageUrl));
        }
        reader.readAsDataURL(file);
      }
      this.updateImageFilter();

      console.log("hellow");
      
     
      
      // const reader = new FileReader();
      // reader.onload = () => {
      //   this.imageUrl = reader.result;
      //   this.updateImageFilter();
      //   sessionStorage.setItem('uploadedImage', this.imageUrl as string);
      // };
      // reader.readAsDataURL(file);
    }
  }
  RemoveImages(){
    this.imageUrl=[];
    sessionStorage.removeItem('ImgArr');
  }

  updateImageFilter(): void {
    this.imageFilter = this.sanitizer.bypassSecurityTrustStyle(
      `brightness(${this.brightness+50}%) contrast(${this.contrast+50}%) saturate(${this.saturation+50}%)`
    );
  }
  downloadImage(): void {
    if (this.imageUrl.length>0 && this.imageFilter) {
      for(let i=0;i<this.imageUrl.length;i++){

        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const img = new Image();
  
        img.onload = () => {
          canvas.width = img.width;
          canvas.height = img.height;
          ctx.filter = `brightness(${this.brightness+50}%) contrast(${this.contrast+50}%) saturate(${this.saturation+50}%)`;
          ctx.drawImage(img, 0, 0);
          canvas.toBlob((blob) => {
            if (blob) {
              const url = URL.createObjectURL(blob);
              const link = document.createElement('a');
              link.href = url;
              link.download = 'filtered_'+i+'.png'; // You can specify the desired file name and format here
              link.click();
              URL.revokeObjectURL(url);
            }
          }, 'image/png');
        };
  
        img.src = this.imageUrl[i] as string;
      }

    }
  }
}